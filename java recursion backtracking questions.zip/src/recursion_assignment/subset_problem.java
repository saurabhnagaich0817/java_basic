package recursion_assignment;

public class subset_problem {
	static int count=0;
	public static void main(String [] args) {
		int [] arr= {1,2,3};
		int target=3;
		print(arr,0,target,"");
		System.out.println("\n"+count);
	}
	private static void print(int [] arr,int index,int target,String ans) {
		if(target == 0) {
			System.out.print(ans+" ");
			count++;
			return;
		}
		if(index == arr.length) {
			return;
		}
		print(arr,index+1,target-arr[index],ans+arr[index]+" ");
		print(arr,index+1,target,ans);
		
	}
		}

