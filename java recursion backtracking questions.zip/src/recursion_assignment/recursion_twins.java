package recursion_assignment;

public class recursion_twins {
static int count=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ques="AXAXA";
		int count=print(ques);
		System.out.println(count);

	}
	private static int print(String ques) {
		if(ques.length() < 3) {
			return 0;
		}
		int a=(ques.charAt(0)== ques.charAt(2))?1:0;
		int b= print(ques.substring(1));
     return a+b;
}
}
