package dsasheet;
import java.util.*;
public class all_occurrence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		int [] arr=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		int m=sc.nextInt();
        all(arr,m,0);
	}
	private static void all(int [] arr,int m,int index){
		if(index == arr.length) {
			return;
		}
		if(arr[index] == m) {
			System.out.println(index + " ");
		}
		all(arr,m,index+1);
	}
	}

