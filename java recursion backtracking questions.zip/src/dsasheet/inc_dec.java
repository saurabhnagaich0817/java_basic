package dsasheet;
import java.util.*;
public class inc_dec {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner sc = new Scanner(System.in);
       int n=sc.nextInt();
       print(n);
       sc.close();
	}
   private static void print(int n) {
	   if(n==0) {
		   return;
	   }
	   
	   System.out.println(n);//for decreasing series
	   print(n-1);
	   System.out.println(n);// for increasing series
   }
}
