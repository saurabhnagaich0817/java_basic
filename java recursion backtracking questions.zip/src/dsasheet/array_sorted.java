package dsasheet;
import java.util.Arrays;
public class array_sorted {
   public static void main(String [] args) {
	   int [] arr= {1,2,3,4,5,6};
	   System.out.println(Arrays.toString(arr));
	   boolean a=print(arr,0);
	   System.out.println(a);
   }
  
   private static boolean print(int [] arr,int index) {
	   if(index ==arr.length-1) {
		   return true;
	   }
	   if(arr[index] > arr[index+1]) {
		   return false;
	   }
	   return print(arr,index+1);
   }
}