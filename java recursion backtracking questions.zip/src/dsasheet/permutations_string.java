package dsasheet;
import java.util.*;
public class permutations_string {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String ques=sc.nextLine();
		print(ques,"");

	}
    private static void print(String ques,String ans) {
    	if(ans.length() == 3) {
    		System.out.println(ans);
    		return;
    	}
    	for(int i=0;i<ques.length();i++) {
    		char ch=ques.charAt(i);
    	print(ques.substring(0,i)+ques.substring(i+1),ans+ch);
    	
    	}
    }
}
