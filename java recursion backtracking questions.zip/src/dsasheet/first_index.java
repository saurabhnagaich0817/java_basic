package dsasheet;
import java.util.*;
public class first_index {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Scanner sc = new Scanner(System.in);
  int n=sc.nextInt();
  int [] arr= new int[n];
  for(int i=0;i<n;i++) {
	  arr[i]=sc.nextInt();
  }
  int m=sc.nextInt();
  System.out.println(first(arr,m,0));
	}
	private static int first(int [] arr,int m,int index) {
		if(index == arr.length) {
			return -1;
		}
		if(arr[index]==m) {
			return index;
		}
		return first(arr,m,index+1);
	}
}