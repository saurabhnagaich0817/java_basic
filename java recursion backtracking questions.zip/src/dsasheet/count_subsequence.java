package dsasheet;
import java.util.*;
public class count_subsequence {
//static int count=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner sc = new Scanner(System.in);
    String ques=sc.nextLine();
    //print(ques,"");
    System.out.println(print(ques,""));
    //System.out.println(count);
    }
    private static int print(String ques,String ans) {
    	if(ques.length()==0) {
    		System.out.println(ans);
    		//count++;
    		return 1;
    	}
    	char ch=ques.charAt(0);
    	int a=print(ques.substring(1),ans);
    	int b=print(ques.substring(1),ans+ch);
    	return a+b;
    }
}
