package dsasheet;
import java.util.*;
public class last_index {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Scanner sc = new Scanner(System.in);
  int n=sc.nextInt();
    int [] arr= new int[n];  
  
  for(int i=0;i<n;i++) {
	  arr[i]=sc.nextInt();
  }
  int m=sc.nextInt();
  System.out.println(last(arr,m,n-1));
	}
	private static int last(int [] arr,int m,int index) {
		if(index < 0) {
			return -1;
		}
		if(arr[index]==m) {
			return index;
		}
		return last(arr,m,index-1);
	}
	}
