package dsasheet;
import java.util.*;
public class climbstairs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n=sc.nextInt();
		climb(n,"");

	}
	private static void climb(int n,String ans) {
		if(n==0) {
			System.out.println(ans);
			return;
		}
		if(n<0) {
			return;
		}
		//climb(n-1,ans+1);
		//climb(n-2,ans+2);
		//climb(n-3,ans+3);
		for(int i=1;i<=3;i++) {
			climb(n-i,ans+i);
		}
	}

}
