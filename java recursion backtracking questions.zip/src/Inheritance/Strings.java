package Inheritance;
import java.util.*;
public class Strings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    StringBuilder sb = new StringBuilder("Archie");
    System.out.println(sb); 
//    System.out.println(sb.charAt(0));
//    sb.setCharAt(0,'S');
//    System.out.println(sb);
   // sb.insert(0, 'S');
    sb.insert(2, 'n');
    System.out.println(sb);
    sb.delete(2,3);
    System.out.println(sb);
    sb.append(" Gupta");
    System.out.println(sb);
    System.out.println(sb.length());
	}

}
