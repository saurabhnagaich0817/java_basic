package tuf;
import java.util.*;
public class inc_by_backtrack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner sc = new Scanner(System.in);
    int n=sc.nextInt();
    print(n,n);
    dec(1,n);
    sc.close();
	}
    private static void print(int i,int n) {
    	if(i == 0) {
    		return;
    	}
    	print(i-1,n);
    	System.out.println(i);
    	//decreasing
    	
    }
    private static void dec(int i,int n) {
    	if(i>n) {
    		return;
    	}
      dec(i+1,n);
      System.out.println(i);
    	
    }
}
