package tuf;

public class fib_series {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=10;
		for(int i=0;i<n;i++) {
		System.out.print(fib(i)+" ");
	}
	}
	private static int fib(int n) {
		if(n==0) {
			return 0;
		}
		if(n ==1 || n ==2) {
			return 1;
		}
		return fib(n-1) +fib(n-2);
	}
}
	
		
			  