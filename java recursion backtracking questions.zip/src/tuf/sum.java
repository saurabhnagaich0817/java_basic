package tuf;

public class sum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int n=5;
  System.out.println(print(n)) ;
   
	}
  private static int print(int n) {
	  if(n==0) {
		  return 0;
	  }
	  return n+print(n-1);
  }
  
  
}
