package tuf;
//parameterized way
import java.util.*;
public class summation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc = new Scanner(System.in);
     int n=sc.nextInt();
     print(n,0);
     sc.close();
	}
    private static void print(int i,int sum) {
    	if(i==0) {
    		System.out.println(sum);
    		return;
    	}
    	print(i-1,sum+i);
    }
}
