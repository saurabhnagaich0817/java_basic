package tuf;

public class palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="madam";
		System.out.println(pal(s,0));

	}
	private static boolean pal(String s,int ans) {
		if(s.length()/2 < ans) {
		return true;
		
	}
		char ch=s.charAt(ans);
		char c =s.charAt(s.length()-ans-1);
		if(ch !=c) 
			return false;
		return pal(s,ans+1);

}
}
