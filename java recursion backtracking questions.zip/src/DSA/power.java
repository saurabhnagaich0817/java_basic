package DSA;

public class power {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=2,n=3;
		System.out.println(pow(x,n));

	}
	public static int pow(int x,int n) {
		if(n==0) {
			return 1;
			
		}
		int sp=pow(x,n-1);
		return x*sp;
	}

}
