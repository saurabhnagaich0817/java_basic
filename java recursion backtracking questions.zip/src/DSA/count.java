package DSA;

public class count {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    int n=10
    		;
    for(int i=1;i < 9;i++) {
    lex_count(n,i);
	}
	}
  private static void lex_count(int n, int ans) {
	 if (ans <= n) {
		 System.out.println(ans);
	 }
	if(ans > n) {
		return;
	}
	for(int i=0;i<= 9;i++) {
		lex_count(n,ans*10+i);
	}
  }
}
