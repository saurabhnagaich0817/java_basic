package DSA;

public class permutations {
   public static void main(String[] args) {
		// TODO Auto-generated method stub
		        String s = "abc";
		        permutation(s, "");
		    }

		    public static void permutation(String s , String ans){

		        if (ans.length() == 3){
		            System.out.println(ans);
		            return;
		        }

		        for(int i = 0; i<s.length();i++){
		            permutation(s.substring(0, i) + s.substring(i+1), ans+s.charAt(i));
		        }
		        
		    }
		}