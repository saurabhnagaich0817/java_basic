package DSA;

public class numeric_strings {
   static String [] keypad = {" ",".+@$","abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
   static String [] searching = {"kartik","sneha","deepak","arnav","shikha","palak","utkarsh","divyam","vidhi","sparsh","akku"};
	public static void main(String[] args) {
		
						String ques = "26";
						rec(ques,"",0);
					}
					public static void rec(String ques, String current,int idx ){
					    if(idx==ques.length()){
					        for (String s : searching) {
				                if (s.contains(current)) {
				                    System.out.println(s);
					    }
					        }
					        return;
					    }
					   int digit = Character.getNumericValue(ques.charAt(idx));
					    String characters = keypad[digit];
					    for (char c : characters.toCharArray()) {
				            rec(ques, current + c, idx + 1);
				        }
				    }
				}