package DSA;

public class climb_stairs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=4;
		climb(n,"");

	}
	private static void climb(int n,String ans) {
		if(n==0) {
			System.out.println(ans);
		}
		if(n<0) {
			return;
		}
		climb(n-1,ans+1);
		climb(n-2,ans+2);
		climb(n-3,ans+3);
		//int a=climb(n-1,ans+1);
		//int b=climb(n-2,ans+2);
		//int c=climb(n-3,ans+3);
		//return a+b+c;
	}

}
