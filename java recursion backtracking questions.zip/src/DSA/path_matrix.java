package DSA;

public class path_matrix {
  static int count=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int [][] arr=new int[3][3];
      System.out.println(path(arr,0,0,""));
	}
	private static int path(int[][] arr,int row,int col,String ans) {
		if(col ==arr[0].length-1 && row ==arr.length-1) {
			System.out.println(ans);
			return 1;
		}
		//if(col == arr[0].length || row == arr.length) {
		//	return;
		//}
		int a=0,b=0;
		if(col < arr[0].length-1)// works without -1 also
		a=path(arr,row,col+1,ans+"H");
		if(row < arr.length-1)
		b=path(arr,row+1,col,ans+"V");
		return a+b
				;
		}
	}


