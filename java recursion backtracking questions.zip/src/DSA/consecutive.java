package DSA;
import java.util.Arrays;
public class consecutive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int arr[]= {200,100,4,1,2,3};
		Arrays.sort(arr);
		int c=Integer.MIN_VALUE;
		int se=1;
		for(int i=1;i<arr.length-1;i++) {
			if(arr[i]==arr[i-1]+1) {
				se=se+1;
				c=Math.max(c, se);
			}
			else {
				se=1;
			}	
		}
		System.out.println(c);
			}
		}
     