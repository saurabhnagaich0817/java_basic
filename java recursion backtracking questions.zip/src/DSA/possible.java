package DSA;

public class possible {
 
 		public static void main(String[] args) {
 			    String ques="1123";
 			    
 			    print(ques,"");
 			}
 			public static void print(String ques,String ans){
 			    if(ques.length()==0){
 			        System.out.println(ans);
 			        return;
 			    }
 			   int digit1 = Character.getNumericValue(ques.charAt(0));
 		        if (digit1 >= 1 && digit1 <= 9) {
 		           print(ques.substring(1), ans + (char) ('a' + digit1 - 1));
 		        }
 		        if (ques.length() >= 2) {
 		            int digit2 = Integer.parseInt(ques.substring(0, 2));
 		            if (digit2 >= 10 && digit2 <= 26) {
 		                print(ques.substring(2), ans + (char) ('a' + digit2 - 1));
 		            }
 			}
 		}
 		}