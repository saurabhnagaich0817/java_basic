package DSA;

public class coin_change {
   static int k=Integer.MAX_VALUE;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       int [] coins= {1,2,3};
       int amount=5;
       
       change(coins,amount,"");
       System.out.println(k);
	}
	private static void change(int [] coins,int amount,String ans ) {
		if(amount == 0) {
			if(ans.length() < k) {
				k=ans.length();
			}
			//System.out.println(ans);
			return;
		}
		if(amount < 0) {
			return;
		}
			for(int i = 0;i < coins.length; i++) {
			change(coins,amount-coins[i],ans+coins[i]);	
			
		}
	}

}
