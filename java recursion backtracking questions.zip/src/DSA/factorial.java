package DSA;

public class factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=5;
		System.out.println(fact(n));

	}
	public static int fact(int n) {
   if(n==0) {
	   return 1;
   }
   int sp=fact(n-1);
   int ans=n*sp;
   return ans;
	}

}
