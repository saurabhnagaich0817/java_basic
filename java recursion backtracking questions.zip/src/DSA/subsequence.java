package DSA;

public class subsequence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		        
		        subseq("abc","");
		    }

		    public static void subseq(String s, String ans){
		        if(s.length()==0){
		            System.out.println(ans);
		            return ;
		        }

		        char ch = s.charAt(0);

		        subseq(s.substring(1),ans);
		        subseq(s.substring(1), ans+ch);
		    }
		}
	


