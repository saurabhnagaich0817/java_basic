package DSA;

public class lexographical_counting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     int n=25;
     counting(n);
    }

    private static void counting(int n) {
        for (int i = 1; i <= 9; i++) {
            order(i, n);
        }
    }

    private static void order(int current, int n) {
        if (current > n) {
            return;
        }

        System.out.println(current);

        for (int i = 0; i <=9 ; i++) {
            if (10 * current + i <= n) {
                order(10 * current + i, n);
            }
        }
    }
}
