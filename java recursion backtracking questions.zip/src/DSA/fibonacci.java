package DSA;

public class fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    System.out.println(fib(10));
	}
	public static int fib(int n) {
		if(n==0||n==1) {
			return n;
		}
		int ans1=fib(n-1);
		int ans2=fib(n-2);
		return ans1+ans2;
	}

}
