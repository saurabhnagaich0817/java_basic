package DSA;

public class max_pathsum{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int [][] arr= {{1,2,3},{4,5,6},{7,8,9}};
      System.out.println(path(arr,0,0,""));
	}
	private static int path(int[][] arr,int row,int col,String ans) {
		if(col ==2 && row ==2) {
			System.out.println(ans);
			return 1;
		}
		//if(col == arr[0].length || row == arr.length) {
		//	return;
		//}
		int a=0;
		int b=0;
		if(col < arr[0].length-1)// works without -1 also
		a=path(arr,row,col+1,ans+arr[row][col]);
		if(row < arr.length-1)
		b=path(arr,row+1,col,ans+arr[row][col]);
		return a+b;
		}
	}
