package LECTURE1;

public class rotate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr= {1,2,3,4,5,6,7};
		swap(arr,0,arr.length-1);
        
        System.out.println(Arrays.toString(arr));
	}
	private static void swap(int [] arr,int st,int ed]) {
		while(st < ed) {
			int temp=arr[st];
			arr[st]=arr[ed];
			arr[ed]=temp;
			st++;
			ed--;
		}
	}

}
