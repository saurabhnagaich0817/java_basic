package LECTURE1;

public class transpose_wave {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int[][]arr= {{1,2,3},{4,5,6},{7,8,9}};
      for(int row=0;row<arr.length;row++) {
    	  for(int col=row;col<arr.length;col++) {
    		  int temp=arr[row][col];
    		  arr[row][col]=arr[col][row];
    		  arr[col][row]=temp;
    		  System.out.println(arr[row][col]+" ");
    	  }
      }
      System.out.println();
	}

}
