package LECTURE1;
import java.util.*;
public class array {
	public static void main(String[args]) {
		int [] arr= {3,6,2,7,1,8};
		System.out.println(max(arr));
		System.out.println(min(arr));
	}
	private static int max(int[] arr) {
		int max=Integer.MIN_VALUE;
		for(int i=0;i< arr.length;i++) {
			if(arr[i]> max) {
				max=arr[i];
			}
		}
		return max;
	}
	private static int min(int[] arr) {
		int min=0;
		for(int i=0;i< arr.length;i++) {
			if(arr[i]< min) {
				min=arr[i];
			}
		}
		return min;

}
}
}
