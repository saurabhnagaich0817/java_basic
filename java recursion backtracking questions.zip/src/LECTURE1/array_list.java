package LECTURE1;
import java.util.ArrayList;
public class array_list { 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>list = new ArrayList<>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		System.out.println(list);
		
		list.remove(1);
		System.out.println(list);
		
		list.remove(2);
		System.out.println(list);
		System.out.println(list.contains(10));
		
		list.size();
	}

}
