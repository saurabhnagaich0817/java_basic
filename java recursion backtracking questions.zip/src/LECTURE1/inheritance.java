package LECTURE1;

public class inheritance {

	public class A{
		public void add(int a ,int b) {
System.out.println(a+b);
		}
	}
	public class B{
		public void mul(int a, int b) {
			System.out.println(a*b);
		}
	}
	public static void main(String[] args) {
		B b=new B();
		b.mul(12,12);
        b.add(12,12);
        b.add(1)
	}
	}
