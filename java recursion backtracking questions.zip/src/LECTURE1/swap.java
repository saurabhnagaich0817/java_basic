package LECTURE1;

public class swap {
	public static void main(String[] args) {
		int[]arr= {1,2,3,4,5};
		int[] brr= {11,12,13,14,15};
		System.out.println(arr[0]+" "+brr[0]);
		swap(arr[0], brr[0]);
		System.out.println(arr[0]+" "+brr[0]);
	}
	private static void swap(inti, int j) {
		int temp=i;
		i=j;
		j=i;
	}

}
