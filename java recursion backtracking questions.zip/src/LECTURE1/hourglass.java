package LECTURE1;
p
import java.util.*;
public class hourglass {
    public static void main(String args[]) {
        // Your Code Here
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        for(int i=0;i<=n;i++){
            for(int j=0;j<=2*n;j++){
                if(j<i||j>2*n-i)
                {System.out.print("  ");}
                else if(j>n)
                {System.out.print(j-n+" ");}
                else
                {System.out.print(n-j+" ");}
            }
            System.out.println();
        }
        for(int i=2*n;i>n;i--){
            for(int j=0;j<=2*n;j++){
                if(j<i-n-1||j>2*n-i+n+1)
                {System.out.print("  ");}
                else if(j>n)
                {System.out.print(j-n+" ");}
                else
                {System.out.print(n-j+" ");}
            }
            System.out.println();
        }
    }
}


