package LECTURE1;

public class substring {
	public static void main(String []args) {
		String s="hello";
		private static void main(String s) {
	for(int i=0;i<=s.length();i++) {
	for(int j=i+1;j<=s.length();j++) {
			System.out.println(s.substring(i,j)+" ");
		}
		System.out.println();
	}
		}
	private static boolean palindrome(String s) {
		int st=0;
		int ed=s.length()-1;
		while(st<ed) {
			if(s.charAt(st)!=s.charAt(ed)) {
				return false;
			}
			st++;
			ed--;
		}
		return true;
	}
	}


