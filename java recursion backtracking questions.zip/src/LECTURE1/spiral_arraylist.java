package LECTURE1;

import java.util.ArrayList;

public class spiral_arraylist {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>list = new ArrayList<>();
		int[][]arr= {{1,2,3,4},{5,6,7,8},{9,10,11,12}};
	     int minr=0;
	     int minc=0;
	     int maxc=arr[0].length-1;
	     int maxr=arr.length-1;
	     int total=arr[0].length*arr.length;
	     int count=0;
	     while(count<total) {
	     for(int i=minc;i<=maxc&&count<total;i++) {
	    	 list.add(arr[minr][i]);
	    	 count++;
	     }
	     minr++;
	     for(int i=minr;i<=maxr&&count<total;i++) {
	    	 list.add(arr[i][maxc]);
	    	 count++;
	     }
	     maxc--;
	     for(int i=maxc;i>=minc&&count<total;i--) {
	    	 list.add(arr[maxr][i]);
	    	 count++;
	     }
	     maxr--;
	     for(int i=maxr;i>=minr&&count<total;i--) {
	    	list.add(arr[i][minc]);
	    	 count++;
	    	 minc++;
	     }
		}
		}
	}


