package LECTURE1;
import java.util.Arrays;
import java.util.Scanner;
public class eko {


	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        
	        int N = scanner.nextInt(); 
	        int M = scanner.nextInt(); 
	        int[] treeHeights = new int[N];

	        for (int i = 0; i < N; i++) {
	            treeHeights[i] = scanner.nextInt();
	        }

	        
	        Arrays.sort(treeHeights);

	        
	        int low = 0;
	        int high = treeHeights[N - 1];
	        int result = 0;

	        while (low <= high) {
	            int mid = (low + high) / 2;

	            if (canCutWood(treeHeights, mid, M)) {
	                result = mid;
	                low = mid + 1;
	            } else {
	                high = mid - 1;
	            }
	        }

	        
	        System.out.println(result);
	    }

	    
	    private static boolean canCutWood(int[] treeHeights, int height, int requiredWood) {
	        long totalWood = 0;

	        for (int i = treeHeights.length - 1; i >= 0; i--) {
	            if (treeHeights[i] > height) {
	                totalWood += treeHeights[i] - height;
	            } else {
	                break; 
	            }
	        }

	        return totalWood >= requiredWood;
	    }
	}

