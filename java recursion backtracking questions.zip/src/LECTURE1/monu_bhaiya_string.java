package LECTURE1;
public class monu_bhaiya_string {
	public class RemoveDuplicateLetters {
		    public static String removeDuplicateLetters(String s) {
		        int[] lastOccurrence = new int[26];
		        boolean[] used = new boolean[26];

		        // Populate the lastOccurrence array with the last index of each character
		        for (int i = 0; i < s.length(); i++) {
		            lastOccurrence[s.charAt(i) - 'a'] = i;
		        }

		        char[] result = new char[26];
		        int resultIndex = 0;

		        for (int i = 0; i < s.length(); i++) {
		            char currentChar = s.charAt(i);

		            // Skip if the character is already used
		            if (used[currentChar - 'a']) {
		                continue;
		            }

		            // Check if the current character is smaller than the last character in result
		            // and the last character in result will occur later in the string
		            while (resultIndex > 0 && currentChar < result[resultIndex - 1]
		                    && i < lastOccurrence[result[resultIndex - 1] - 'a']) {
		                used[result[--resultIndex] - 'a'] = false;
		            }

		            // Add the current character to result and mark it as used
		            result[resultIndex++] = currentChar;
		            used[currentChar - 'a'] = true;
		        }

		        // Build the result string from the result array
		        return new String(result, 0, resultIndex);
		    }

		    public static void main(String[] args) {
		        String s = "bcabc";
		        System.out.println(removeDuplicateLetters(s));
		    }
		}

	}


