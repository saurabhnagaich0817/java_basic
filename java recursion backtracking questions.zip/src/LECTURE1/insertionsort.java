package LECTURE1;

public class insertionsort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
