package LECTURE1;
import java.util.*;
public class binary {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int ans=0;
		int mul=1;
		while(n>0) {
			int rem=n%2;
			ans=ans+rem*mul;
			n/=2;
			mul*=10;
		}
		System.out.println(ans);
	}

}
