package LECTURE1;

public class good_substring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     String s="Khushi";
     int max=0,couunt=0;
     for(int i=0;i<n)
	}

}
