package LECTURE1;
import java.util.Arrays;
public class bubblesort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  int [] arr = {5,4,3,2,1};
  System.out.println( Arrays.toString(arr));
  for(int pass=0;pass< arr.length-1;pass++) {
  for(int i=0;i< arr.length-1;i++) {
	  if(arr[i]>arr[i+1]) {
		  int temp= arr[i];
		  arr[i]=arr[i+1];
		  arr[i+1]=temp;
	  }
  }
	  
	}
	System.out.println( Arrays.toString(arr));

}
}
