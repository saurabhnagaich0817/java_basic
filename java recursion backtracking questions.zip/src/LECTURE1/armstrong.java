package LECTURE1;
import java.util.*;
public class armstrong {
	
	    public static boolean isArmstrongNumber(int number) {
	        int originalNumber = number;
	        int numDigits = String.valueOf(number).length();
	        int armstrongSum = 0;

	        while (number > 0) {
	            int digit = number % 10;
	            armstrongSum += Math.pow(digit, numDigits);
	            number /= 10;
	        }

	        return armstrongSum == originalNumber;
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        int n = scanner.nextInt();

	        if (isArmstrongNumber(n)) {
	            System.out.println("true");
	        } else {
	            System.out.println("false");
	        }
	    }
}



