package LECTURE1;

public class pal_substring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        String s="nitin";
        for(int i=0;i<=s.length();i++) {
        	for(int j=i+1;j<=s.length();j++) {
        		String str=s.substring(i,j);
        		if(ispalindrome(str))
        			System.out.println(str+" ");
        	}
        	System.out.println();
       
        }
	}
	private static boolean ispalindrome(String s) {
		int st=0;
		int ed=s.length()-1;
		while(st<ed) {
			if(s.charAt(st)!=s.charAt(ed)) {
				return false;
			}
			st++;
			ed--;
		}
		return true;
	}
	}


