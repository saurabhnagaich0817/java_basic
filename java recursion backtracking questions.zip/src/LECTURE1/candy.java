package LECTURE1;
import java.util.*;
public class candy {

    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        int t = sc.nextInt(); 

	        while (t--> 0) {
	            double x = sc.nextInt(); 
	            double n = sc.nextInt(); 

	            double rem = x % n;
	            double ret = rem;

	            System.out.println(ret);
	        }

	        sc.close();
	    }
	}



