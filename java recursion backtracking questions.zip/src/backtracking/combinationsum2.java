package backtracking;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class combinationsum2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[]arr= {10,1,2,7,6,1,5};
		Arrays.sort(arr);
		int target=8;
		List<Integer>list = new ArrayList<>();
		List<List<Integer>>ll = new ArrayList<List<Integer>>();
	
		print(arr,target,list,ll,0);
		System.out.println(ll);
	}
	
	private static void print(int[]arr,int target,List<Integer>list,List<List<Integer>>ll,int lp){
		

		if(target==0) {
			//System.out.println(list);
			ll.add(new ArrayList<>(list));
			if(!ll.contains(list))
			//ll.add(list);
			return;
		}
		if(target<0) {
			return;
		}
		for(int i=lp;i<arr.length;i++) {
			if(i !=lp&& arr[i]==arr[i-1])
			continue;
			list.add(arr[i]);
			print(arr,target-arr[i],list,ll,i+1);
			list.remove(list.size()-1);
		}
	}
}