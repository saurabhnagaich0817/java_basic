package backtracking;

public class diagonal_pathsum {
   static int count=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	      int [][] arr=new int[3][3];
	      path(arr,0,0);
	      System.out.println(count); 
		}
private static void path(int[][] arr,int row,int col) {
			if(row ==arr.length-1 && col ==arr[0].length-1) {
				//System.out.println(ans);
				count++;
				return;
			}
			if(row < 0 || col < 0 || row == arr.length||col == arr[0].length || arr[row][col]==1  ) {
				return;
			}

			int [] c= {0,1,0,-1};
			 int [] r= {1,0,-1,0};
			//int [] c= {1,0,-1,0};
			// int [] r= {0,1,0,-1};
			 arr[row][col]=1;
			 for(int i=0; i< r.length;i++) {
			 path(arr,row+r[i],col+c[i]);
			 }
			 arr[row][col]=0;
			}
		}

	
