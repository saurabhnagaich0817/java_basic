package backtracking;

public class word_search {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	 char [][] board={{'A','B','C','E'},{'S','F','C','S'},{'A','D','E','E'}};
		String word = "ABCCED";
			    for (int i = 0; i < board.length; ++i)
			      for (int j = 0; j < board[0].length; ++j)
			        if (search(board, word, i, j, 0)) {
			          return true;
			         return false;
			  }
	}

			  private boolean search(char [][] board, String word, int i, int j, int s) {
			    if (i < 0 || i == board.length || j < 0 || j == board[0].length)
			      return false;
			    if (board[i][j] != word.charAt(s) || board[i][j] == '*')
			      return false;
			    if (s == word.length() - 1)
			      return true;

			    final char cache = board[i][j];
			    board[i][j] = '*';
			    final boolean isExist = search(board, word, i + 1, j, s + 1) || //
			                            search(board, word, i - 1, j, s + 1) || //
			                            search(board, word, i, j + 1, s + 1) || //
			                            search(board, word, i, j - 1, s + 1);
			    board[i][j] = cache;

			    return isExist;
			  }
			}
	
