package backtracking;

public class Pathsofmatrix {
   static int count=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		      int [][] arr=new int[3][3];
		      path(arr,0,0,"");
			}
	private static void path(int[][] arr,int row,int col,String ans) {
				if(col ==arr[0].length-1 && row ==arr.length-1) {
					System.out.println(ans);
					return;
				}
				if(row < 0 || col < 0 || row == arr.length||col == arr[0].length ||row ==arr.length || arr[row][col]==1  ) {
					return ;
				}
				 if(arr[row][col] == 0) {
					 arr[row][col]=1;
					 path(arr,row+1,col,ans+"V");
					 path(arr,row,col+1,ans+"H");
					 path(arr,row-1,col,ans+"V");
					 path(arr,row,col-1,ans+"H");
				 }
				}
			}
